abstract class Electrodomestico {
    protected String marca;
    protected String consumo;

    public Electrodomestico(String marca, String consumo) {
        this.marca = marca;
        this.consumo = consumo;
    }
}
public interface Operacion {
    public void ejecutar(int a, int b);
}

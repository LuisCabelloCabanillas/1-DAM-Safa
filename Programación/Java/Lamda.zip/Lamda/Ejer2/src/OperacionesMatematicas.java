public interface OperacionesMatematicas {
    void sumar(int a, int b);
    void restar(int a, int b);
}

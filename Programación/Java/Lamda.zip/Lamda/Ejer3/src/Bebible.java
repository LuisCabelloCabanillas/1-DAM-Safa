public interface Bebible {
    void beber();
}

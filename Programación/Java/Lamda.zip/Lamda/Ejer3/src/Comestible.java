public interface Comestible {
    void comer();
}

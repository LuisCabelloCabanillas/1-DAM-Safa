public class Gazpacho {
    public void beber() {
        System.out.println("Bebiendo gazpacho");
    }

    public void comer() {
        System.out.println("Comiendo gazpacho");
    }
}

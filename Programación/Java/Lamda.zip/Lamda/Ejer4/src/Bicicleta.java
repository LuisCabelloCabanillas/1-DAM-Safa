public class Bicicleta {
    public void mover() {
        System.out.println("La bicicleta se mueve");
    }

    public void detener() {
        System.out.println("La bicicleta se detiene");
    }
}

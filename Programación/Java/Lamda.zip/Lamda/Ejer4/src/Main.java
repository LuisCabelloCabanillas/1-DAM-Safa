public class Main {
    public static void main(String[] args) {
        Bicicleta bicicleta = new Bicicleta();
        bicicleta.mover();
        bicicleta.detener();
    }
}

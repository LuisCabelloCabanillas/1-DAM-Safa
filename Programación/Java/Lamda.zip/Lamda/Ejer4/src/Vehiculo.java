public interface Vehiculo {
    void mover();
    void detener();
}

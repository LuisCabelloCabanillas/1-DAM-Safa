public class CocineroItaliano {
    public void cocinar(){
    prepararIngredientes();
    cocinarPlato();
    servirPlato();
}

    void prepararIngredientes(){
        System.out.println("Preparando ingredientes Italianos");
    }

    void cocinarPlato(){
        System.out.println("Cocinando plato Italiano");
    }

    void servirPlato() {
        System.out.println("Sirviendo plato Italiano");
    }
}

public class Main {
    public static void main(String[] args) {
        CocineroJapones japones = new CocineroJapones();
        japones.cocinar();
        CocineroItaliano italiano = new CocineroItaliano();
        italiano.cocinar();
    }
}

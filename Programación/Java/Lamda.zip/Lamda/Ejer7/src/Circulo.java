public class Circulo {
    public void mostrarInfo(){
        System.out.println("Soy un círculo");
    }
}

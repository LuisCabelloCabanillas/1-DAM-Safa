public class Main {
    public static void main(String[] args) {
        Triangulo triangulo = new Triangulo();
        Circulo circulo = new Circulo();
        triangulo.mostrarInfo();
        circulo.mostrarInfo();
    }
}

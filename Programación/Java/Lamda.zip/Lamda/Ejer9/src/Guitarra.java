public class Guitarra extends InstrumentoMusical{
    void tocar() {
        System.out.println("Tocando la guitarra");
    }
}

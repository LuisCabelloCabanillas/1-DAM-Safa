abstract class InstrumentoMusical {
    abstract void tocar();
}

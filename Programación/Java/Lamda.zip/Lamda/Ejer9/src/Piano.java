public class Piano extends InstrumentoMusical{
    void tocar(){
        System.out.println("Tocando el piano");
    }
}

public class Cancion implements Reproducible{
    public void reproducir(){
        System.out.println("Reproduciendo cancion");
    }
}

public class Main {
    public static void main(String[] args) {
        Pelicula pelicula = new Pelicula();
        pelicula.reproducir();
        Cancion cancion = new Cancion();
        cancion.reproducir();
    }
}

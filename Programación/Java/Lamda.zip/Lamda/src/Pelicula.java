public class Pelicula implements Reproducible{
    public void reproducir(){
        System.out.println("Reproduciendo pelicula");
    }
}

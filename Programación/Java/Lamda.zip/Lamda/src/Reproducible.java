public interface Reproducible {
    public void reproducir();
}
